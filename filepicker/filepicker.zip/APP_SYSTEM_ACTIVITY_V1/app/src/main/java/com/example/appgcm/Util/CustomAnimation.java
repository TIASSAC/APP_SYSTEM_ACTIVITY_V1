package com.example.appgcm.Util;

/**
 * Created by HOME on 12/20/2015.
 */
public enum CustomAnimation {
    LEFT_RIGHT,
    IN_OUT,
    RIGTH_LEFT
    /****/
}
