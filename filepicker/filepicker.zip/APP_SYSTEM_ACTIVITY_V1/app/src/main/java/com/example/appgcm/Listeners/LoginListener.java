package com.example.appgcm.Listeners;

public interface LoginListener {

    void goToMain();

    void loadService();
}
